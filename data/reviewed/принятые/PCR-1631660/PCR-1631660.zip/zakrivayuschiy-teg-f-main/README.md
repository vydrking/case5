https://github.com/onlilonly/zakrivayuschiy-teg-f
https://onlilonly.github.io/zakrivayuschiy-teg-f/