https://github.com/Foxike157/slozhno-sosredotochitsya-fd
